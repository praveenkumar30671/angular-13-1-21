﻿using Castle.Components.DictionaryAdapter;
using Couchbase;
using Couchbase.KeyValue;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using realone.Interface;
using realone.Controllers;
using realone.model;
using Microsoft.Extensions.Logging;
using Couchbase.Core.Exceptions;
using Polly;








namespace realone.service
{
    public class Empdetailservice : IEmpdetailService

    {
        private readonly ILogger<Empdetailservice> _logger;

        public Empdetailservice(ILogger<Empdetailservice> logger)
        {
            _logger = logger;
        }


        public async Task<Empdetails> DeleteEmployees(ICluster cluster, int id)
        {
            try
            {


              //  var queryResult = await cluster.QueryAsync<Empdetails>("SELECT id,name,empid,emailid,srccs,phonenumber,skill FROM Employeedetails where id= " + id.ToString(), new Couchbase.Query.QueryOptions());
                var bucket = await cluster.BucketAsync("Employeedetails");
                var collection = bucket.DefaultCollection();

                await collection.RemoveAsync(id.ToString());
                return null;
            }
            catch (BucketNotFoundException)
            {
                _logger.LogError("Bucker not found");
                throw;
            }
        }


        public async Task<Empdetails> GetEmployeeBYid(ICluster cluster, int id)
        {
            Empdetails employee = new Empdetails();
            var queryResult = await cluster.QueryAsync<Empdetails>("SELECT id,name,empid,emailid,srccs,phonenumber,length,skill FROM Employeedetails where id=" + id, new Couchbase.Query.QueryOptions());

            await foreach (var row in queryResult)
            {
                employee = row;
            }
            if (employee == null)
            {
                _logger.LogWarning($"Id with {id} not available in the bucket");
            }

            return employee;
        }

        public async Task<List<Empdetails>> GetEmployees(ICluster cluster, Paging paging)

        {
            try
            {

                var queryResult = await cluster.QueryAsync<Empdetails>($"SELECT id,name,empid,emailid,srccs,phonenumber,length,skill FROM Employeedetails OFFSET {paging.start} LIMIT {paging.end}", new Couchbase.Query.QueryOptions());

                List<Empdetails> empList = new List<Empdetails>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }

                return empList;
            }
            catch (IndexFailureException)
            {
                _logger.LogError("Bucket not found");
                throw;
            }
        }


        public async Task<ICluster> Initialize()
        {
            try
            {
                var policy = Policy.Handle<Exception>()
                    .WaitAndRetryAsync(2, Count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {
                    _logger.LogInformation("Retry to connect couchbase for EmployeeController...");
                    await retry();

                });
                return await retry();
            }
            catch(AuthenticationFailureException)
            {
                _logger.LogError("Authentication error");
                throw;
            }
        }

        public async Task<ICluster> retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Administrator", "Password");
            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();

            return cluster;
        }

        public async Task<Empdetails> PutEmployeeBYid(ICluster cluster, int id, Empdetails value)
        {
            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();
            var collectiondata = await collection.UpsertAsync(id.ToString(), value);

            if (collectiondata == null)
            {
                _logger.LogError("Error in update");
            }

            return null;

        }




        //create
        public async Task<Empdetails> PostEmploye(ICluster cluster, Empdetails value)
        {

            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
            var collectiondataa = await collection.InsertAsync(idvalue.ToString(), value);
            if (collectiondataa == null)
            {
                _logger.LogError("Error in creating");
            }

            return null;
        }



        public async Task<List<Empdetails>> GetEmployeescount(ICluster cluster)
        {

            List<Empdetails> employees = new List<Empdetails>();
            var queryResults = await cluster.QueryAsync<Empdetails>("SELECT id,name,empid,emailid,srccs,phonenumber,length,skill FROM Employeedetails", new Couchbase.Query.QueryOptions());
        
            await foreach(var row in queryResults)
            {
            employees.Add(row);
            }
              return employees;
        }

      
    }

}




















