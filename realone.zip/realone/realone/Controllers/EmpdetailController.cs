﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using realone.Interface;
using realone.service;
using Couchbase;
using realone.model;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNet.OData;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;



namespace realone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize (AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]

    
    public class EmpdetailController : ControllerBase
    {
        private readonly IEmpdetailService _service;
        private readonly ILogger<EmpdetailController> _logger;

        public EmpdetailController(IEmpdetailService service, ILogger<EmpdetailController> logger)
        {
            this._logger = logger;
            _logger.LogInformation(1, "NLog injected into EmpdetailController");
            _service = service;
        }



        // GET: api/<employeedetails>
        [HttpGet]
        [Authorize (Roles = "superadmin,user,admin")]
        
        public async Task<EmployeeCollection> Get([FromQuery] Paging paging)
        {
            EmployeeCollection emp = new EmployeeCollection();
            _logger.LogInformation("geting all employees");
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployees(couchClient, paging);
            var employee = await _service.GetEmployeescount(couchClient);
            if (employees == null)
            {
                _logger.LogWarning("Can't get Employees");

            }
            int count = employee.Count;

            

            emp.employees = employees;
            emp.employeeCount = count;

            return emp;
        }



        // GET api/<employeedetails>/5
        [HttpGet("{id}")]
        [Authorize (Roles = "superadmin,admin, user")]

        
        public async Task<Empdetails> Get(int id)
        {
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployeeBYid(couchClient, id);
            if (employees.id == 0)
            {
                _logger.LogInformation($"Employee with Id- {id} not found");
                _logger.LogError("This is an error");
                return null;
            }
            return employees;
        }


        //update
        // PUT api/<employeedetails>/5
        [HttpPut("{id}")]
        [Authorize(Roles = "superadmin, admin")]

       
        public async Task <Empdetails> Put(int id,[FromBody] Empdetails value)
        {
            var couchClient = await _service.Initialize();
            await _service.PutEmployeeBYid(couchClient, id, value);
            _logger.LogInformation($"Updating this Id-{id}");
            return null;

        }

        

        // DELETE api/<employeedetails>/5
        [HttpDelete("{id}")]
        [Authorize (Roles = "superadmin")]

       
        public async Task<Empdetails> Delete(int id)
        {
            var couchClient = await _service.Initialize();
            await _service.DeleteEmployees(couchClient, id);
            _logger.LogInformation($"Deleting this Id-{id}");
            return null;
        }




         // POST api/<EmployeeController>
        [HttpPost]
        [Authorize (Roles = "superadmin,admin")]

       
        public async Task Post([FromBody] Empdetails value)
        {
            var couchClient = await _service.Initialize();
            await _service.PostEmploye(couchClient, value);
            _logger.LogInformation($"Posting this {value} Employee");

        }









    }
}
