﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace realone.model
{
    public class Credentials
    {
        public string username { get; set; }

        public string pwd { get; set; }
    }
}
