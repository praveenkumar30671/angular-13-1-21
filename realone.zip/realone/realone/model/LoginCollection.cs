﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace realone.model
{
    public class LoginCollection
    {
        public Logindetails logindetails { get; set; }

        public string token { get; set; }
    }
}
