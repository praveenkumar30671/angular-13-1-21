﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Couchbase;
using realone.model;
using realone.Interface;
using Microsoft.AspNetCore.Mvc;


namespace realone.model
{
    public class Logindetails
    {

        public int id { get; set; }

        public string pwd { get; set; }

        public string designation { get; set; }
      
       public string username { get; set; }

       public string logintype { get; set; }
      

    }
}
