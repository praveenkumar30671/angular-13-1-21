import { Injectable } from '@angular/core';
import { from, observable } from 'rxjs';
import { HttpClient, HttpHeaders,HttpClientModule} from '@angular/common/http';
import { UserInfo } from 'src/app/Login/user-info'
import { Observable } from 'rxjs';
import { Employeedetails } from '../EmployeesDetail/employeedetails';
import { $ } from 'protractor';
import {EmployeeCollection } from '../employee-collection';
import { LoginCollection } from '../login-collection';


 


@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  
private readonly url:string='https://localhost:44364/api/Empdetails';
  constructor(private http:HttpClient) {}

  private baseUrl='https://localhost:44364/api/Empdetails';
    getUserInfo(username ,pwd): Observable<LoginCollection>
    {
      return this.http.get<LoginCollection>('https://localhost:44364/api/Login?username='+username+'&pwd='+pwd);
    }
    getEmployeesList(start,end):Observable<EmployeeCollection>{
      
      var tokenHeader = new HttpHeaders().set("Authorization", "Bearer " +localStorage.getItem("token") ); 
      return this.http.get<EmployeeCollection>('https://localhost:44364/api/Empdetail?start=' +start +'&end='+end,{headers:tokenHeader});

    }
    getEmployeesListbyid(id):Observable<Employeedetails[]>{
      var tokenHeader =new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem("token")})
      return this.http.get<Employeedetails[]>(this.baseUrl+ "/" + id,{headers:tokenHeader});
    }



    createlogin(from :UserInfo):Observable<UserInfo>
    {
      var tokenHeader =new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem("token")})
      return this.http.post<UserInfo>("https://localhost:44364/api/Login",from,{headers: tokenHeader});
    }

   create(form :Employeedetails):Observable<Employeedetails>
   {
    var tokenHeader =new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem("token")})
     return this.http.post<Employeedetails>( this.url,form,{headers:tokenHeader});
   }

   deletee(id:any):Observable<Employeedetails>
   {
    var tokenHeader =new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem("token")})
     return this.http.delete<Employeedetails>(this.url + "/" + id,{headers:tokenHeader})
   }

   update(form :Employeedetails):Observable<Employeedetails>
   {
    var tokenHeader =new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem("token")})
     return this.http.put<Employeedetails>( `${this.url}/${form.id}`,form,{headers:tokenHeader});
   }
}
