import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { UserInfo } from '../Login/user-info';
import jwt_decade from "jwt-decode";


@Injectable({
  providedIn: 'root'
})
export class AdminService implements CanActivate {
  userinfo: UserInfo;
  canActivate(route: import("@angular/router").ActivatedRouteSnapshot): boolean {

      this.userinfo = JSON.parse(localStorage.getItem('idd'));
      console.log(this.userinfo);
      if ((this.userinfo.logintype == "admin")||(this.userinfo.logintype == "superadmin")) {
        {
          var token = localStorage.getItem("token")
          var decoded = jwt_decade(token);
          console.log(decoded);
        }
  
        return true;
      } else {
        return false;
      }
  

   

  }


  constructor() { }
}
