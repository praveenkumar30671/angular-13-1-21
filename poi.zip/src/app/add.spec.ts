import { Add } from './add';

describe('Add', () => {
  it('should create an instance', () => {
    expect(new Add()).toBeTruthy();
  });
});
