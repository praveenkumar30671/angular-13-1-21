export class Employeedetails {
    id:number;
    name: string;
    empid: number;
    srccs:string;
    emailid: string;
    phonenumber: number;
    skill: string;
    
}

