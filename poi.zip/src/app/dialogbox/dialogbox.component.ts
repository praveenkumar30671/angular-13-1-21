import { Component, OnInit } from '@angular/core';
import { UserInfo } from '../Login/user-info';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-dialogbox',
  templateUrl: './dialogbox.component.html',
  styleUrls: ['./dialogbox.component.css']
})
export class DialogboxComponent implements OnInit {
// s :UserInfo;
// ss:UserInfo;
  constructor(private loginservice:LoginServiceService) {
   
    // console.log(JSON.parse(localStorage.getItem('idd')))
   
   }

  ngOnInit(): void {
    // // this.s=JSON.parse(localStorage.getItem('idd'))
    // // console.log(this.s)
    
 
  }

  
 

  


}
