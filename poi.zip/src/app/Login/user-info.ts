export class UserInfo {
    designation:string;
    id:string;
    username: string;
    pwd: string;
    logintype:string;

}
