import {UserInfo } from './Login/user-info';


export class LoginCollection {
    logindetails:UserInfo[];
    token:string;
}
